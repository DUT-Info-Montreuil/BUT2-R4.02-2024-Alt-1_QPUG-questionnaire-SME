package org.univ_paris8.iut.montreuil.qdev.tp2024.gr1.QPUG;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
